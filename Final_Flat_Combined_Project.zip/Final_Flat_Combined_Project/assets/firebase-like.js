/* assets/firebase-like.js
Floating Profile + Like UI. Saves likes to Firestore under /users/{uid}/likes/{courseId}
Requires Firebase SDK (v12+) included on pages or uses module imports inside.
*/
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { getFirestore, doc, setDoc, deleteDoc, getDoc } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAR6vn11SSzD3YQmern4jSeN8oo7gbmuYU",
  authDomain: "career-conseil.firebaseapp.com",
  projectId: "career-conseil",
  storageBucket: "career-conseil.appspot.com",
  messagingSenderId: "833313313531",
  appId: "1:833313313531:web:6b55bb6ef604158683165e"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

function createFloatingUI() {
  const container = document.createElement('div');
  container.id = 'floating-like-container';
  container.style.position = 'fixed';
  container.style.bottom = '22px';
  container.style.right = '22px';
  container.style.display = 'flex';
  container.style.flexDirection = 'column';
  container.style.gap = '12px';
  container.style.zIndex = '9999';
  document.body.appendChild(container);

  const profileBtn = document.createElement('button');
  profileBtn.id = 'floating-profile-btn';
  profileBtn.className = 'floating-btn floating-profile';
  profileBtn.innerHTML = '👤';
  profileBtn.title = 'Profile';
  profileBtn.onclick = () => window.location.href = 'profile.html';
  container.appendChild(profileBtn);

  const likeBtn = document.createElement('button');
  likeBtn.id = 'floating-like-btn';
  likeBtn.className = 'floating-btn floating-like';
  likeBtn.innerHTML = '🤍';
  likeBtn.title = 'Like course';
  container.appendChild(likeBtn);

  return { likeBtn, profileBtn };
}

function courseInfo() {
  const h1 = document.querySelector('h1');
  const name = h1 ? h1.textContent.trim() : document.title || location.pathname.split('/').pop();
  const file = location.pathname.split('/').pop();
  const id = file.replace(/\W+/g,'_') || name.replace(/\W+/g,'_');
  return { id, name, link: file };
}

async function setVisual(btn, liked) {
  if (liked) {
    btn.classList.add('liked');
    btn.innerHTML = '💖';
  } else {
    btn.classList.remove('liked');
    btn.innerHTML = '🤍';
  }
}

async function init() {
  const { likeBtn } = createFloatingUI();
  const course = courseInfo();

  onAuthStateChanged(auth, async (user) => {
    if (!user) {
      await setVisual(likeBtn, false);
      likeBtn.onclick = () => { alert('Please login to like courses.'); window.location.href='login.html'; };
      return;
    }

    const docRef = doc(db, 'users', user.uid, 'likes', course.id);
    const snap = await getDoc(docRef);
    await setVisual(likeBtn, snap.exists());

    likeBtn.onclick = async () => {
      const exists = (await getDoc(docRef)).exists();
      if (exists) {
        await deleteDoc(docRef);
        await setVisual(likeBtn, false);
        alert('Removed from liked courses');
      } else {
        await setDoc(docRef, { id: course.id, name: course.name, link: course.link, likedAt: new Date() });
        await setVisual(likeBtn, true);
        alert('Added to liked courses');
      }
    };
  });
}

try { init(); } catch(e) { console.error(e); }
