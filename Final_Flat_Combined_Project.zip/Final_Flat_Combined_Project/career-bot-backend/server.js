import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
console.log("OPENAI_API_KEY:", process.env.OPENAI_API_KEY);

const app = express();
app.use(cors());
app.use(express.json());

// Chat API endpoint
app.post("/api/chat", async (req, res) => {
  const message = req.body.message;
  if (!message) return res.json({ reply: "Please send a message." });

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: message }]
      })
    });

    const data = await response.json();
    console.log("OpenAI raw response:", JSON.stringify(data, null, 2));

    if (!data.choices || !data.choices[0].message)
      throw new Error("No choices returned");

    res.json({ reply: data.choices[0].message.content });
  } catch (err) {
    console.error("OpenAI error:", err.message);
    res.json({ reply: "Sorry, I'm having trouble responding right now." });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
